import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Color;

public class SlideShow extends JFrame {

	//Declare Variables
	private JPanel slidePane;
	private JPanel textPane;
	private JPanel buttonPane;
	private CardLayout card;
	private CardLayout cardText;
	private JButton btnPrev;
	private JButton btnNext;
	private JLabel lblSlide;
	private JLabel lblTextArea;

	/**
	 * Create the application.
	 */
	public SlideShow() throws HeadlessException {
		initComponent();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initComponent() {
		//Initialize variables to empty objects
		card = new CardLayout();
		cardText = new CardLayout();
		slidePane = new JPanel();
		textPane = new JPanel();
		textPane.setBackground(Color.BLUE);
		textPane.setBounds(5, 470, 790, 50);
		textPane.setVisible(true);
		buttonPane = new JPanel();
		btnPrev = new JButton();
		btnNext = new JButton();
		lblSlide = new JLabel();
		lblTextArea = new JLabel();

		//Setup frame attributes
		setSize(800, 600);
		setLocationRelativeTo(null);
		/**
		 * Changed Title Card from top 5 destinations to Top 5 Detox and Wellness Destinations Slide Show to adhere to product owner refocus request
		 */
		setTitle("Top 5 Detox and Welness Destinations SlideShow");
		getContentPane().setLayout(new BorderLayout(10, 50));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		//Setting the layouts for the panels
		slidePane.setLayout(card);
		textPane.setLayout(cardText);
		
		//logic to add each of the slides and text
		for (int i = 1; i <= 5; i++) {
			lblSlide = new JLabel();
			lblTextArea = new JLabel();
			lblSlide.setText(getResizeIcon(i));
			lblTextArea.setText(getTextDescription(i));
			slidePane.add(lblSlide, "card" + i);
			textPane.add(lblTextArea, "cardText" + i);
		}

		getContentPane().add(slidePane, BorderLayout.CENTER);
		getContentPane().add(textPane, BorderLayout.SOUTH);

		buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));

		btnPrev.setText("Previous");
		btnPrev.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				goPrevious();
			}
		});
		buttonPane.add(btnPrev);

		btnNext.setText("Next");
		btnNext.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				goNext();
			}
		});
		buttonPane.add(btnNext);

		getContentPane().add(buttonPane, BorderLayout.SOUTH);
	}

	/**
	 * Previous Button Functionality
	 */
	private void goPrevious() {
		card.previous(slidePane);
		cardText.previous(textPane);
	}
	
	/**
	 * Next Button Functionality
	 */
	private void goNext() {
		card.next(slidePane);
		cardText.next(textPane);
	}

	/**
	 * Method to get the images
	 */
	private String getResizeIcon(int i) {
		String image = ""; 
		if (i==1){
			//Updated image from TestImage1 to AquaPark for detox and wellness shift as per product owner
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/AquaPark.jpg") + "'</body></html>";
		} else if (i==2){
			//Updated image from TestImage2 to Altaussee, Austria for detox and wellness shift as per product owner
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/Altaussee.jpeg") + "'</body></html>";
		} else if (i==3){
			//Updated image from TestImage3 to WellnessResort for detox and wellness shift as per product owner
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/WellnessResort.jpg") + "'</body></html>";
		} else if (i==4){
			//Updated image from TestImage4 to Yellowstone National Park for detox and wellness shift as per product owner
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/YellowStone.jpg") + "'</body></html>";
		} else if (i==5){
			//Updated image from TestImage5 to Himalayas for detox and wellness shift as per product owner
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/Himalayas.jpg") + "'</body></html>";
		}
		return image;
	}
	
	/**
	 * Method to get the text values
	 */
	private String getTextDescription(int i) {
		String text = ""; 
		if (i==1){
			// Changed the text to match the new images and added a brief description on location. Credit: Creative Commons Zero, Public Domain Dedication by Wellnesskurim
			text = "<html><body><font size='5'>#1 Wellness Kurim.</font> <br>Wellness and Relaxation is just a quick trip away.</body></html>";
		} else if (i==2){
			// Changed the text to match the new images and added a brief description on location. Credit: Photographer: Ioan Sendroiu, Uploaded by: Rodrigo.Argenton
			text = "<html><body><font size='5'>#2 Altaussee, Austria.</font> <br>Detox your body and mind in this beautiful land.</body></html>";
		} else if (i==3){
			// Changed the text to match the new images and added a brief description on location. Credit: Munirpt
			text = "<html><body><font size='5'>#3 Algarve, Portugal.</font> <br>Wellness is their priority at the Wellness Resort.</body></html>";
		} else if (i==4){
			// Changed the text to match the new images and added a brief description on location. Credit: Irene Steeves
			text = "<html><body><font size='5'>#4 Yellowstone National Park.</font> <br>Reconnect with nature and heal yourself.</body></html>";
		} else if (i==5){
			// Changed the text to match the new images and added a brief description on location. Credit: Ms. Sarah Welch
			text = "<html><body><font size='5'>#5 Himalayas, India.</font> <br>Align your spirits and mend your mind at the many temples in the Himalayas.</body></html>";
		}
		return text;
		/*
		 *Full credit for each image and link to website found in resources under imagecredits.txt
		 *location, who posted image, and direct link can be found there as well
		 */
	}
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				SlideShow ss = new SlideShow();
				ss.setVisible(true);
			}
		});
	}
}